
"use strict";

let ObjectsStamped = require('./ObjectsStamped.js');
let DetectionInfo = require('./DetectionInfo.js');

module.exports = {
  ObjectsStamped: ObjectsStamped,
  DetectionInfo: DetectionInfo,
};
